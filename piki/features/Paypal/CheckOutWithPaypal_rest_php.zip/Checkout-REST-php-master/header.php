<html>
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Checkout with PayPal Demo</title>
        <!--Including Bootstrap style files-->
        <link href="css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="container-fluid">
        <div class="well">
            <h2 class="text-center">PayPal Checkout REST API Demo</h2>
        </div>

